﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenTecnico
{
    public class MoneyParts
    {
        decimal[][] dResultado;
        
        public decimal[][] Build(decimal dParametro)
        {
            decimal[] denominaciones = { (decimal)0.05, (decimal)0.1, (decimal)0.2, (decimal)0.5, 1, 2, 5, 10, 20, 50, 100, 200 };

            decimal ddivision = 0;
            int indice = 0;
            int iResult = 0;
            bool valida;
            for (int i = 0; i < denominaciones.Length; i++)
            {
                
                ddivision = dParametro / denominaciones[i];
                valida = int.TryParse(ddivision.ToString(), out iResult);
                if (valida)
                {
                    if (ddivision >= 1)
                    {
                        indice++;
                    }
                }
            }

            dResultado = new decimal[indice][];

            int cont = 0;

            for (int i = 0; i < denominaciones.Length; i++)
            {
                ddivision = dParametro / denominaciones[i];
                valida = int.TryParse(ddivision.ToString(), out iResult);
                if (valida)
                {
                    dResultado[cont] = new decimal[(int)ddivision];
                   
                    int j = 1;
                    while (j <= ddivision)
                    {
                        dResultado[cont][j - 1] = denominaciones[i];
                        j++;
                    }

                    cont++;
                }
            }
            
            return dResultado;
        }

    }
}
